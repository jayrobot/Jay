                        CaseLinr Version 5.9.5
                            32-bit version

                            Ed Adasiewicz
                          260 Richmond Lane
                    Village of Lakewood, IL  60014
                           (815) 459-3618

                             eda@mc.net
                       http://user.mc.net/~eda



CaseLinr is a 32-bit Microsoft Windows 95 application which prints and 
saves liners (J-cards) for conventional audiocassette, DAT cassette, 
Mini Disc and 8mm tape boxes. Fussy audiophiles can now enjoy ultimate 
control over typefaces, fold and cut lines, text rotation, liner 
dimensions, tab stops and annotation styles and view an on-screen 
WYSIWYG version of the liner before printing.  You can also define and 
save formats that can be used as templates for new liners, 
sequentially print multiple liners (even on the same page) and include 
pictures in various graphics formats.  The image displayed on the CRT 
screen approximates what will actually be printed.  The printed result 
is quite accurate and can be cut, folded, and then inserted into an 
empty (preferably clear plastic) container for the medium.

To install CaseLinr, start by unzipping the file.  If the name of the 
file looked like "clinrxxx.zip" where xxx are numbers, then click on 
(or execute) SETUP.EXE within Windows 95 and follow the setup wizard.  
If the name of the file was clupdate.zip then copy the files into the 
directory (folder) where you previously installed CaseLinr, and (at 
your leisure) open and save all of your existing formats to update 
their internal version number.

For help about CaseLinr, read the online help available under the help
menu.  If you have been using a pre-5.0 version of CaseLinr and you
decide to remove the old version from your system, then you can also
delete the file CASELINR.INI after you have used this version at least
once.

CaseLinr is distributed as shareware; it is not free software. This 
allows you to use the program and determine if you like it and whether 
it fits your needs. If you like CaseLinr and find it useful, you are 
requested to support it by registering (i.e. sending me money).  The 
unregistered version will perform all the same functions as the 
registered version.  HOWEVER, THE UNREGISTERED VERSION IS FLAWED IN 
THAT IT PRINTS A SMALL "CASELINR ADVERTISEMENT" ON THE LINER. If you 
have registered a previous version, you don't have to re-register this 
version.  However, if you feel a burning desire to send me more money, 
I will not refuse it!  Users who registered a version prior to 5.0 (I 
have everyone in a database) should contact me (preferably via e-mail) 
and I will inform them of their User Name and Key so that they can 
print an unblemished liner.

See the online help for the current single user registration fee for
CaseLinr. A single user license means that CaseLinr can be installed
on multiple machines but only used on one machine at a time -- similar
to how one uses a book. If CaseLinr is to be installed and used on
multiple machines simultaneously, then you should contact the author
about a multi-user license.

All funds should be in US dollars -- cash, check (drawn on US banks
only), money order, or postal money order.  I don't wish to belittle
foreign currency, but the local banks (in a small town) charge a very
unattractive (to me) fee to exchange currency.  No credit cards -- I
haven't made it to the big time. Please make all checks payable to Ed
Adasiewicz, and forward your payment along with your name, address
(electronic and postal), and comments to:

          Ed Adasiewicz
          260 Richmond Lane
          Village of Lakewood, IL  60014

You can also print the ASCII text file ORDER.TXT.

Registered users receive a User Name and Key that unlocks the program 
and allows them to print liners without the "CaseLinr advertisement".

The CaseLinr program is being made available on an "as is" basis, and
carries no warranties, express or implied.  The author (Ed Adasiewicz)
shall in no way be held liable for any damages resulting from the use
of this program or the media on which it is distributed, including,
without limitation, loss of business profits, interruption of
business, loss of information, damage to equipment, any warranty of
merchantability or fitness for a particular purpose, or any other
incidental or consequential damages.


Revision History:
----------------
5.9.5 - Made the program more user-friendly when opening files,
        liner and format, that weren't created by CaseLinr.

5.9.4 - Got rid of the cryptic error message "Unable to allocate 0
        bytes of memory at 'grfx.1'".

        Fixed a problem where Shift+Del (cut) and Shift+Ins (paste)
        while editing either Songs, Title, or Side Letter Text or
        adding a New Feature or Choice caused the program to abort.

        Fixed a problem where Undo while editing either Songs, Title,
        or Side Letter Text or adding a New Feature or Choice caused 
        the program to abort.

5.9.3 - Fixed a problem where empty song text was not being correctly
        handled - the program assumed that there was 1 character. This
        would cause the "All songs won't fit" message to be displayed
        if overflow repeat was set to zero, 1-Up Sides was checked,
        Text / Songs Side B... was chosen, and OK was selected but no
        text was ever entered.

        Added Alt+O as a shortcut to the OK button wherever multiple
        lines of text can be added -- e.g. Title, Songs, ...

        Added abbreviations which allow for textual substitutions.

        Added custom printing -- fit as many liners as you think you
        can on a single page.

5.9.2 - Fixed the Last Font button -- it did not work across liners
        and/or formats unless you were lucky.

        Modified Resize Window logic to also work on initial startup
        after restoring window size and position.

        Added templates for Mini Disc and 8mm Tape.

        Replaced repeatedly printing the word "Sample" down the 
        diagonal of the liner in the unregistered version with printing
        a small CaseLinr advertisement on the liner.
      
5.9.1 - Fixed "blank with side" features -- the selected choice would
        be printed / displayed at random vertical positions.

        Cleaned up screen when switching to a liner / format with a
        smaller width and resize window is not checked.

5.9 - Modified Out-Of-Memory reporting to tell where and how much.

      Rewrote font handling logic -- couldn't figure out how the old
      one even worked!?

      Fixed a problem where text cutting with Ctrl+X could cause the
      program to abort.

      The program will now distinguish between songs not fitting on
      Side A versus Side B.

      Fixed registration of file types -- it was broke.

      Rewrote font and picture I/O -- some funky outcomes were possible.

      Fixed several memory leaks -- hopefully, out-of-memory reporting
      will not occur.

5.8 - Fixed a bug where tabs within pasted text were not recognized.

      Fixed a bug where File / SaveAs caused the newly created file
      to be treated as read-only.

      Fixed a bug where default file extents were not being correctly
      used in the common file dialog boxes.

5.7 - Added a toolbar with tooltips.

      Added the ability to click in the Title Area, Side A Song Area,
      and Side B Song Area to bring up the associated text entry
      dialog box.

      Added context menu support (i.e. right mouse click floating
      menus) inside the Feature Flpa, Title Area, Side A Song Area,
      and Side B Song Area.

      Added a checkable menu item (Apply Last Font) under the Fonts
      submenu which (when checked) will automatically do an Apply
      operation after a Last Font operation in the Title Lines,
      Format Sides and Songs - Sides A/B dialog boxes -- but not the
      Change Feature or Change Sided Feature Choice dialog boxes.

      Added a checkable menu item (Resize Window) under the Format
      submenu which (when checked) will automatically resize the main
      window to fit the liner size whenever it changes -- e.g. open
      file, select from the recent file list, select apply in Format
      Liner.

      Added OK buttons wherever there were Apply buttons.

      Modified the way feature names and choices are added and
      allowed for changing names and choices.

      Added an automatic update of a feature's font when the feature
      is changed between sided and non-sided.

      Modified all dialog boxes to be more sensitive to unsaved
      changes.

      Replaced disabled features in the unregistered version with
      repeatedly printing the word "Sample" down the diagonal of the
      liner.

      Added stretching a picture to fill the entire liner or selected
      portions of the liner.

      Added centering a picture within the entire liner or selected
      portions of the liner.

      Added support for JPG, PCX, PNG, and TGA graphics formats.

      Modified the program to delete all unused font definitions at
      the time a liner or format is saved.

      Fixed a bug where defining more than 128 fonts caused the
      program to abort.

      Fixed a bug which resulted in a GPF for the following: open an
      existing liner file; select Text / Songs Side A; select Text /
      Songs Side B; go back to the Side A dialog box and delete any
      character from any song.

      Fixed a bug which resulted in a GPF when the Windows color
      scheme was changed while CaseLinr was in use.

5.6 - Fixed a bug which caused multi-copy printing of liners, to
      printers which support multiple copies, to print the square of
      the number requested.

5.5 - Added a recent file list feature.

      Fixed bottom song margins, they were broke.

      Modified the way file types are registered.

      Automatically save and restore window size and position.

5.4 - Fixed a bug which caused 2-Up multi-copy printing to not work
      with certain printers.

5.3 - Fixed a bug which caused the program to abort after pasting text
      with Ctrl+V in songs, sides, and title.

      Fixed a bug where the program would not terminate if exit was
      requested (either menu or close box), the liner had changed,
      and yes was selected from the "save changes" dialog box.

5.2 - Fixed a bug which caused the program to abort if all features
      are removed and then all of the side letters were removed.

5.1 - Fixed window creation so that a horizontal scroll bar is not
      needed.

      Added Bisect Area to Format/Liner and removed cross-disabling
      between 1-Up Sides and Bisecting.

      Added file type registration.

5.0 - Converted to 32-bit Windows 95 complete with long file names,
      new look common dialog boxes, and all the other goodies.

      Added user registration and verification.

      Fixed several memory leaks.

      Fixed Ctrl+Tab to work in places where Tabs are allowed
      (i.e. Title and Songs).

      Fixed handling of consecutive Tabs.

      Removed the infamous Keep Configuration option.

      Replaced Print Setup with Page Setup.

4.8 - Fixed a problem where the bisect sides line would be drawn
      outside of the liner boundaries if 0 was specified for the
      size of the song overflow area.

      Added support for multiple song overflow areas.

      Fixed a memory allocation bug associated with songs over 128
      characters.

      Allowed for 2-up printing in portrait mode and landscape mode.

      Added (endpoints) line style.

4.7 - Fixed a problem with not being able to add "extra" song, title,
      or side letter characters in increments greater than 128 bytes.

4.6 - Rewrote the "fonting" algorithms.

      Made Text Songs, Text Title, Format Features, Format Liner,
      Format Sides, Format Songs, Format Title, and Format Pictures
      into modeless dialog boxes which do not automatically close,
      so that the results may be viewed and played with.

      Removed Text buttons from Format Songs and Format Title.

      Updated the caselinr file format spec.

      Fixed a problem with the Time and Date buttons in Format Sides.

      Allowed for the same feature to be added more than once in
      Format / Features.

4.5 - Fixed the problem where setup would not work if the zipped file
      was unzipped to a hard drive.

      Added support for Windows bitmap (*.BMP) graphics files.

4.4 - Fixed the problem where a Centered Feature is subsequently
      displayed as a Centered with sides Feature.

      Added Cut, Copy, Paste, Undo, and Clear to the 'System menu'
      for song and title entry.

      Added font rotation.

      Fixed checking that all songs will fit on the liner.

      Fixed reading in old (pre 4.x) liners and converting features.

      Fixed several tabbing and fonting errors.

      Truncated all measurements to 4 decimal places and updated
      DAT.FMT.

      Added a setup program.

      Remember last format used and use this format as the default
      for the next startup.

      Fixed problem where printing 2up and print to file didn't work
      together.

4.3 - Fixed enabling/disabling the Add and Remove buttons in Format
      Sides after a different Feature is selected from the combo box.

      Fixed a problem where measurements with "too many" decimal
      places were going negative.

      Modified title and song entry so that a Tab character appears as
      "2 angle brackets (greater than signs) pointing to the right".

      Renamed the "Per Side" feature type to "Centered with sides"
      and added 2 feature types "Adjacent with sides" and "Blank with
      sides".

      Risized the window containing the liner when its width is
      changed.

4.2 - Fixed the Format / Save... dialog box to display the file name
      of the current format rather than random garbage characters.

      Fixed Format / Sides... so that the font of Side Letter Text
      can be changed.

      Added the Apply Font button wherever the Font... button appears.

      Added Tab Stops and Default Units to the Format / Liner dialog
      box.

      Allowed entry of Tab characters in titles and songs.

4.1 - Fixed the "do you want to save" dialog to actually save the
      file.

      Fixed a problem with more than 13 fonts when you actually use
      the 13th font.

      Added 2-Up and multi-file printing.

      Added several accelerator keys.

      Added menu item to NOT save the printer configuration to
      CASELINR.INI since some people had trouble with this feature.

4.0c - Fixed another (GPF causing) bug related to freeing too many
       fonts.

4.0b - Made the bisecting vertical line obey the song margins.

       Modified an internal routine which may fix problems with
       printer drivers GPFing.

4.0a - Fixed problem with not being able to enter more than 8 songs in
       a new liner.

       Fixed problem with not being able to "unselect" Invert Image,
       1-Up Sides, and Bisect Sides.

4.0 - Modified dialog boxes to use Windows 3.1 common dialogs.

      Remembered directory of last opened file.

      Enlarged title and song entry dialog boxes.

      Introduced use of formats as opposed to CASELINR.INI.

      Auto conversion of old file.

      Dropped DAT and title over songs features.

      Added many margins and alignments.

      No more TWIPS, allowed for more generic measurements.

      Added unlimited features.

      Added unlimited fonts.

3.9c - Fixed problem with songs overlapping side letter when Invert
       Image option is selected.

3.9b - Fixed a problem with the Invert Image and Bisect Sides options
       which I broke in 3.9 and didn't totally fix in 3.9a.

3.9a - Fixed the Invert Image option which I broke in 3.9.

3.9 - Added DAT option.

      Added right title alignment and title wrap indent.

      Added absolute feature order.

      Added liner dimensions.

      Added printing of title over songs with new font.

      Changed several buttons from Cancel to Close once a Save has
      been performed.

      Rebuilt for Windows 3.1 ONLY.

3.8 - Added 1-up sides and made it mutually exclusive with Bisect
      sides.

      Added "null" (i.e. none) cut and fold lines.

      Added individual side letter printing selection.

      Moved song margin and wrap indent from global layout to side
      layout.

      Added left/center/right song alignment and Save / Restore to
      side layout.

3.7 - Fixed a problem where 3.6 would not print.

      Fixed spelling of February.

3.6 - Fixed a problem where an "unwanted character" occurred every 128
      characters in long songs.

3.5 - Rebuilt application for Windows 3.x using Microsoft C/C++ 7.0.

      Fixed UAE problem if fonts are changed while CaseLinr is in use.

3.4 - Changed Current Date button in side layout to Short Date.

      Added Long Date button to side layout.

      Made Short Date, Long Date, and Current Time operate as
      instructed in the International section of Control Panel, but
      weekdays are not used.

3.3 - Fixed not being able to overwrite an existing cassette file even
      if the user specifically requested it.

      Sorted Files and Sizes list boxes.

      Fixed problem where a 4 point font would cause 48 to be
      highlighted in the Sizes list box if 4 was not in the list.

3.2 - Fixed UAE introduced in 3.1 and fixed saving global layout which
      worked in 3.0.  Both problems were a result of moving,
      incorrectly, all text strings to the resource file.

3.1 - Reversed action of Enter and Ctrl+Enter during entry of multiple
      lines in Titles and Songs -- Enter goes to next line, Ctrl+Enter
      depresses the default button.

      Fixed a problem with very long song titles.

3.0 - Started using private profile file (caselinr.ini) rather than
      win.ini.

      Provided automatic conversion from win.ini to caselinr.ini.

      Added online help.

      Modified file format slightly.

      Added Print Setup and Reset All Fonts.

      Added directory list boxes to Open and Save.

      Added top and left margins for printing.

      Split font handling into 2 dialog boxes and added more options.

      Added margins and indents for songs.

      Added title alignment, margins, and splitting.

      Modified features so that both the name and value are user
      settable.

      Changed a lotta radio buttons to combo boxes.

2.1 - Centered the liner, both horizintally and vertically, within the
      page specified in Control Panel prior to printing.

      Shrunk size of about box.

      J-card icon now blends in with background color.

2.0 - Insured that the program functioned correctly under Windows 3.0.

      The Ctrl-Enter key combination must now be used, instead of the
      Enter key, for entering multiple lines in Titles and Songs.

      Added an alternate icon.

      Added system menus to all of the dialog boxes.

      Default extensions (*.CAS) are now properly displayed in the
      Open... dialog box.

      OK in the global layout box only causes scrolling up or down
      if inversion was actually selected or deselected.

1.2 - Added Bisect Side checkbox to global layouts.

      Changed the Invert menu option to Invert Image checkbox in
      global layouts so that it could be saved/reset and written
      to a cassette file.

1.1 - Added the Invert menu option.

1.0 - Initial release (fixed various bugs in CLFREE).