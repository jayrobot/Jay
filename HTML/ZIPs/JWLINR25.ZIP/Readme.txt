                         JewlLinr Version 2.5
                            32-bit version

                            Ed Adasiewicz
                          260 Richmond Lane
                    Village of Lakewood, IL  60014
                           (815) 459-3618

                             eda@mc.net
                       http://user.mc.net/~eda



JewlLinr is a 32-bit Microsoft Windows 95 application that prints and 
saves liners for jewel boxes.  JewlLinr comes with templates (formats) 
to produce liners for both CD (2 parts) and ZIP disk (1 part) jewel 
cases.  You have total control over typefaces, fold and cut lines, 
text rotation, liner dimensions, tab stops and text styles and can 
view an on-screen WYSIWYG version of the liner before printing.  You 
can also define and save formats that can be used as templates for new 
liners, sequentially print multiple liners (even on the same page) and 
include pictures in various graphics formats.  You can define 
additional 'areas' anywhere on a liner. Text can be entered and 
stylized within an area; and graphics can be stretched over or 
centered within an area. The image that is displayed on the CRT screen 
approximates what will actually be printed.  The printed result is 
quite accurate and can be cut (into 1 or more parts), folded and then 
inserted into an empty (preferably clear plastic) jewel case.

To install JewlLinr, start by unzipping the file.  If the name of the
file looked like "jwlinrxx.zip" where xx are numbers, then click on
(or execute) SETUP.EXE within Windows 95 and follow the setup wizard.
If the name of the file was jwupdate.zip then copy the files into the
directory (folder) where you previously installed JewlLinr, and (at
your leisure) open and save all of your existing formats to update
their internal version number.

For help about JewlLinr, read the online help available under the help
menu.

JewlLinr is distributed as shareware; it is not free software. This 
allows you to use the program and determine if you like it and whether 
it fits your needs. If you like JewlLinr and find it useful, you are 
requested to support it by registering (i.e. sending me money).  The 
unregistered version will perform all the same functions as the 
registered version.  HOWEVER, THE UNREGISTERED VERSION IS FLAWED IN 
THAT IT PRINTS A SMALL "JEWLLINR ADVERTISEMENT" ON THE LINER. If you 
have registered a previous version, you don't have to re-register this 
version.  However, if you feel a burning desire to send me more money, 
I will not refuse it!

See the online help for the current single user registration fee for
JewlLinr. A single user license means that JewlLinr can be installed
on multiple machines but only used on one machine at a time -- similar
to how one uses a book. If JewlLinr is to be installed and used on
multiple machines simultaneously, then you should contact the author
about a multi-user license.

All funds should be in US dollars -- cash, check (drawn on US banks
only), money order, or postal money order.  I don't wish to belittle
foreign currency, but the local banks (in a small town) charge a very
unattractive (to me) fee to exchange currency.  No credit cards -- I
haven't made it to the big time. Please make all checks payable to Ed
Adasiewicz, and forward your payment along with your name, address
(electronic and postal), and comments to:

          Ed Adasiewicz
          260 Richmond Lane
          Village of Lakewood, IL  60014

You can also print the ASCII text file ORDER.TXT.

Registered users receive a User Name and Key that unlocks the program
and allows them to print liners without the "JewlLinr advertisement".

The JewlLinr program is being made available on an "as is" basis, and
carries no warranties, express or implied.  The author (Ed Adasiewicz)
shall in no way be held liable for any damages resulting from the use
of this program or the media on which it is distributed, including,
without limitation, loss of business profits, interruption of
business, loss of information, damage to equipment, any warranty of
merchantability or fitness for a particular purpose, or any other
incidental or consequential damages.


Revision History:
----------------
2.5 - Made the program more user-friendly when opening files,
      liner and format, that weren't created by JewlLinr.

      Fixed a bug where not entering at least one top left corner
      for each part of the liner within the Custom-Print Layout
      caused custom printing to abort.

2.4 - Got rid of the cryptic error message "Unable to allocate 0
      bytes of memory at 'grfx.1'".

      Fixed a problem where Shift+Del (cut) and Shift+Ins (paste)
      while editing "Text" caused the program to abort.

      Fixed a problem where Undo while editing "Text" caused the
      program to abort.

2.3 - Fixed a bug where a blank page would be printed (wasted) is you
      were printing only cover inserts and the printer had to be
      placed in landscape mode.

      Added Alt+O as a shortcut to the OK button wherever multiple
      lines of text can be added -- e.g. any of the text dialog boxes.

      Added abbreviations which allow for textual substitutions.

      Added custom printing -- fit as many liners as you think you
      can on one or two pages.
        
2.2 - Fixed the Last Font button -- it did not work across liners
      and/or formats unless you were lucky.
      
      Fixed a bug which caused eratic printing when the same font was
      used in 2 (or more) areas and the areas had different rotations.

      Replaced repeatedly printing the word "Sample" down the 
      diagonal of the liner in the unregistered version with printing
      a small JewlLinr advertisement on the liner.
      
2.1 - Modified Out-Of-Memory reporting to tell where and how much.

      Rewrote font handling logic -- couldn't figure out how the old
      one even worked!?

      Fixed a problem where text cutting with Ctrl+X could cause the
      program to abort.

      Fixed registration of file types -- it was broke.

      Rewrote font and picture I/O -- some funky outcomes were possible.

      Fixed several memory leaks -- hopefully, out-of-memory reporting
      will not occur.

2.0 - Fixed a bug where tabs within pasted text were not recognized.

      Fixed a bug where default file extents were not being correctly
      used in the common file dialog boxes.

1.9 - Added a checkable menu item (Apply Last Font) under the Fonts
      submenu which (when checked) will automatically do an Apply
      operation after a Last Font operation in the Text dialog box.

      Added OK buttons wherever there were Apply buttons.

      Modified the handling of unsaved changes to ask about exiting
      before checking the validity of input.

      Put back the old BMP rooutines.

      Fixed the blinking toolbar when scrolling.

      Replaced the annoying about window in the unregistered version
      with repeatedly printing the word "Sample" down the diagonal of
      the liner.

1.8 - Added a toolbar with tooltips.

      Added better support for 1-part liners (e.g.zip drive).

      Added context menu support (i.e. right mouse click floating
      menus) inside of text areas.

      Modified all dialog boxes to be more sensitive to unsaved
      changes.

      Replaced disabled features in the unregistered version with an
      annoying timed about window.

      Added stretching a picture to fill a cover or text area.

      Added centering a picture within a cover or text area.

      Added support for JPG, PCX, PNG, and TGA graphics formats.

      Fixed a bug where defining more than 128 fonts caused the
      program to abort.

      Modified the program to delete all unused font definitions at
      the time a liner or format is saved.

1.7 - Fixed a bug that caused the program to terminate with an illegal
      operation error during the addition of a bitmap picture.

1.6 - Fixed a bug that caused multi-copy printing of liners, to
      printers that support multiple copies, to print the square of
      the number requested.

1.5 - Added a recent file list feature.

      Automatically save and restore window size and position.

1.4 - Fixed a bug with printing the spines (i.e. rotated text) on
      certain printers.

1.3 - Fixed a bug that caused multi-copy printing of liners, split
      across two pages, to not work with certain printers.

1.2 - Fixed a problem where the program aborted if all entered text
      was deleted from a text area, the liner was saved and then
      opened.

      Fixed the install script to place the correct shell command
      in the registry.

1.1 - Fixed a problem where memory was being incorrectly released from
      within the text entry dialog box causing the program to abort.

1.0 - Initial release